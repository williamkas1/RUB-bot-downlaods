const fs = require('fs');
const path = require('path');


//Settings
let ScriptCanCopyItself = false; // Set to true or false to control if the script can copy itself
let SpecialFileTypesIsRare = true; // Set to true or false to control if it should generate alot of valid file formats or should stay true to its rng
//Settings


function getRandomString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}


function getRandomExtension() {
  const rareExtChars = 'bajszipextdfvcronhlm234'; 
  const commonExtensions = [
    '.exe', '.txt', '.mp3', '.mp4', '.md', '.js', '.zip', '.rar', '.bat', '.html', '.css', 
    '.json', '.csv', '.log', '.xml', '.png', '.jpg', '.gif', '.svg', '.wav', '.aac', '.flac', 
    '.mkv', '.avi', '.mov', '.ppt', '.pdf', '.docx', '.xlsx', '.ts', '.java', '.c', '.cpp', 
    '.py', '.rb', '.go', '.sh', '.bat', '.ps1', '.apk', '.torrent', '.iso', '.tar', '.gz', 
    '.7z', '.dmg', '.pkg', '.pub', '.epub', '.mpg', '.webp', '.yml', '.toml', '.ini', '.bat'
  ];

  if (!SpecialFileTypesIsRare) {
    
    if (Math.random() < 0.1) {
      
      return `${rareExtChars.charAt(Math.floor(Math.random() * rareExtChars.length))}${rareExtChars.charAt(Math.floor(Math.random() * rareExtChars.length))}${rareExtChars.charAt(Math.floor(Math.random() * rareExtChars.length))}`;
    } else {
      
      return commonExtensions[Math.floor(Math.random() * commonExtensions.length)];
    }
  } else {
    
    return `${rareExtChars.charAt(Math.floor(Math.random() * rareExtChars.length))}${rareExtChars.charAt(Math.floor(Math.random() * rareExtChars.length))}${rareExtChars.charAt(Math.floor(Math.random() * rareExtChars.length))}`;
  }
}

function getRandomContent() {
  const lines = Math.floor(Math.random() * 5) + 1;
  return Array.from({ length: lines }, () => getRandomString(Math.floor(Math.random() * 300) + 1)).join('\n');
}

function createFile() {
  const fileName = `${getRandomString(Math.floor(Math.random() * 15) + 1)}.${getRandomExtension()}`;
  let content = getRandomContent();
  if (content.length > 15) {
    content = content.slice(0, 15) + '...';
  }
  fs.writeFileSync(fileName, content);
  console.log(`I created: ${fileName} with content ${content}`);
}



function copyFile() {
  let files = fs.readdirSync(__dirname);

  
  if (!ScriptCanCopyItself) {
    if (files.includes('rng.js') || files.includes('run.bat')) {
      console.log("I am not allowed to copy myself 3:");
      return;
    }
    files = files.filter(file => !['rng.js', 'run.bat'].includes(file));
  }

  if (files.length === 0) return;

  const targetFile = files[Math.floor(Math.random() * files.length)];
  const extension = path.extname(targetFile);
  const newName = `${getRandomString(Math.floor(Math.random() * 15) + 1)}${extension}`;
  fs.copyFileSync(targetFile, newName);
  console.log(`I copied: ${targetFile} to ${newName}`);
}

function deleteFile() {
  const files = fs.readdirSync(__dirname).filter(file => !['rng.js', 'run.bat'].includes(file));
  if (files.length === 0) {
    console.log("I have nothing to delete.");
    return;
  }

  const targetFile = files[Math.floor(Math.random() * files.length)];
  fs.unlinkSync(targetFile);
  console.log(`I deleted: ${targetFile}`);
}

function randomAction() {
  const actions = [createFile, copyFile, deleteFile];
  const action = actions[Math.floor(Math.random() * actions.length)];
  action();
}

setInterval(randomAction, 1000);
