const axios = require('axios');
const fs = require('fs');
const path = require('path');

const target = require('./target.bag');

const url = target.url;

const domain = url.replace(/^https?:\/\//, '').split('/')[0];

const downloadDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadDir)) {
  fs.mkdirSync(downloadDir);
}

const fileName = path.join(downloadDir, domain + '.html');

axios.get(url, { responseType: 'arraybuffer' })
  .then(response => {
    fs.writeFileSync(fileName, response.data);
    console.log(`Page downloaded as ${fileName}.`);
  })
  .catch(error => {
    console.error('Error downloading the page:', error);
  });
